package com.springprograms;

public class HelloWorld {
	private String name;
	private int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void getMessage() {
		System.out.println("name is: " + name+"\nId is: "+id);
	}
}