package com.springprogram;

//import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import org.springframework.core.io.ClassPathResource;
//import org.springframework.core.io.Resource;


public class Client {

	public static void main(String[] args) {
		/*Employee e=new Employee();
		e.setEid(101);
		e.setEname("Ravina Bhosale");
		e.setEaddress("Satara");
		
		System.out.println("Employee Details: "+e);*/
		
		
		//Spring Way | IOC (inversion of control)
		ApplicationContext context = new ClassPathXmlApplicationContext("employeebean.xml");
		Employee e1=(Employee) context.getBean("emp1");
		Employee e2=(Employee) context.getBean("emp2");
		System.out.println(e1);
		System.out.println(e2);
		
		ClassPathXmlApplicationContext cxt=(ClassPathXmlApplicationContext)context;
		cxt.close();
		//Resource resourse =new ClassPathResource("employeebean.xml");
		//BeanFactory factory= new XmlBeanFactory(resourse);
		
		
		}

	}


