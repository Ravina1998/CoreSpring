package net.codejava.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudWebAppApplication.class, args);
	}

}
