package net.codejava.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
